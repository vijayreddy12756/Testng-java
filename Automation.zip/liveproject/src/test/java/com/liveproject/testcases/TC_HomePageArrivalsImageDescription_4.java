package com.liveproject.testcases;



import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;



public class TC_HomePageArrivalsImageDescription_4 extends Baseclass {

	
	@Test
	public void clickandcheckarrivals() throws Exception
	{
		TC_HomepageImageinArrivalNavigate_3 na=new TC_HomepageImageinArrivalNavigate_3();
		na.clickandverify();
		na.clickonimageandaddtobasket();
	
	
	/*
	@Test
	public void scrolltillelementvisible()
	{
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		 WebElement Element = driver.findElement(By.xpath("//a[contains(text(),'Description')]"));

	        //This will scroll the page till the element is found		
	        js.executeScript("arguments[0].scrollIntoView();", Element);
	        System.out.println(js);
	}
	
*/
	
		Thread.sleep(1000);
		
		WebElement ele=driver.findElement(By.xpath("//div[@id='tab-description']//p[contains(text(),'The Selenium WebDriver Recipes book is a quick pro')]"));
		
		String txt=ele.getText();
		System.out.println(txt);
		
		
		
	}
}
	
	
	
	


