package com.liveproject.testcases;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_HomepageBookinBasketPrice_6 extends Baseclass {
	
	@Test
	public void bookprice() throws Exception{

	TC_HomepageImageinArrivalNavigate_3 as=new TC_HomepageImageinArrivalNavigate_3();
	
	as.clickandverify();
	as.clickonimageandaddtobasket();
	//works for single line text verification
	//boolean Actual=driver.findElement(By.xpath("//div[@class='summary entry-summary']")).getText().contains("Selenium Ruby.695 in stock");
	
	
	String Actual=driver.findElement(By.xpath("//div[@class='summary entry-summary']")).getText();
	
	String Expected="SeleniumRuby?500.00TheSeleniumWebDriverRecipesbookisaquickproblem-solvingguidetoautomatedtestingwebapplicationswithSeleniumWebDriver.695instockADDTOBASKETCATEGORY:seleniumTAGS:ruby,selenium";
	String afterspace=Actual.replaceAll("[\\n\\t ]", "");
	
	System.out.println("from webpage"+ afterspace );
	System.out.println("expected"+Expected );
	System.out.println(afterspace.toLowerCase().compareTo(Expected.toLowerCase()));
	//System.out.println(afterspace.toLowerCase() == Expected.toLowerCase());

	/*
	if(afterspace.equalignorecase(Expected)
			{
		System.out.println("both are same");
			}
	
	
			
	*/
	
	
	
	
	
	/*
	List<String> pricedetailslist=new ArrayList();
	pricedetailslist.add(pricedetails);
	System.out.println("details from webpage"+ pricedetailslist);
	
	
	
	List<String> pricedata=new ArrayList();

		pricedata.add("Selenium Ruby");
		
		pricedata.add("\n");
		
		pricedata.add("?500.00");
		pricedata.add("\n");
		pricedata.add("The Selenium WebDriver Recipes book is a quick problem-solving guide to automated testing web applications with Selenium WebDriver.");
		pricedata.add("\n");
		pricedata.add("695 in stock");
		pricedata.add("\n");
		pricedata.add("ADD TO BASKET");
		
		System.out.println("data from list"+ pricedata);
		
		
	//Assert.assertEquals(pricedata, pricedetailslist);
		
		
		for(String data:pricedetailslist)
		{
		 if(data.equalsIgnoreCase("?500.00"))
		 {
			 System.out.println("price matched");
			 
		 }
		 else
		 {
			 System.out.println("price not found");
		 }
			
		}
		

	//System.out.println("pricedetails of book added in basket are"+ pricedetails );
	
	*/
	
	
	}

}
