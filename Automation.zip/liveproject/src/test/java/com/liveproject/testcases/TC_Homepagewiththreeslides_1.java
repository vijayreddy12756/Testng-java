package com.liveproject.testcases;

import org.testng.annotations.Test;

import com.liveproject.pageobjects.Homepage;

public class TC_Homepagewiththreeslides_1 extends Baseclass {
	
	
	
	@Test
	public void click() throws Exception
	{
		
		Homepage hm=new Homepage(driver);
		
		hm.shopmenu();
		hm.homemenu();
		
	}

}
