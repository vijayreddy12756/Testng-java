package com.liveproject.testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TC_HomepagewiththressArrivals_2 extends Baseclass {
	
	@Test
	public void clickonbutton() throws Exception
	{
		TC_Homepagewiththreeslides_1 ts=new TC_Homepagewiththreeslides_1();
		ts.click();
	}
	@Test
	public void verifypagecontainsonlythreearrivals()
	{
		
		List<WebElement> arrivals=driver.findElements(By.xpath("//ul[@class=\"products\"]"));
		
	int size=arrivals.size();
	
	if(size<4)
	{
		System.out.println("number of arrivales are 3");
		
	}
	else
	{
		System.out.println("arrivals are more");
	}
      
	
	//System.out.println("number of arrivals are"+ size);
	
		
		}		
				

}
