package com.liveproject.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.liveproject.pageobjects.Homepage;

public class Demo extends Baseclass{
	
	
	
	@Test
	public void test() throws Exception
	{
		Homepage hm=new Homepage(driver);
		hm.shopmenu();
		hm.homemenu();
		hm.clickonimage();
		hm.addbooktobasket();
		
		String Actual=driver.findElement(By.xpath("//div[@class='summary entry-summary']")).getText();
		
		
		String Expected="SeleniumRuby?500.00TheSeleniumWebDriverRecipesbookisaquickproblem-solvingguidetoautomatedtestingwebapplicationswithSeleniumWebDriver.695instockADDTOBASKETCATEGORY:seleniumTAGS:ruby,selenium";
		String afterspace=Actual.replaceAll("[\\n\\t ]", "");
		
		System.out.println("from webpage"+  afterspace );
		System.out.println("expected"+   Expected );
		System.out.println(afterspace.toLowerCase().compareTo(Expected.toLowerCase()));
		System.out.println(afterspace.equalsIgnoreCase(Expected));

	}
	
	

}
