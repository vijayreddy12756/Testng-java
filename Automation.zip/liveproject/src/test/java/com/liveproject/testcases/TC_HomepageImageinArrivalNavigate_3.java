package com.liveproject.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.liveproject.pageobjects.Homepage;

public class TC_HomepageImageinArrivalNavigate_3 extends Baseclass {
	
	
	@Test
	public void clickandverify() throws Exception
	{
		TC_HomepagewiththressArrivals_2 as=new TC_HomepagewiththressArrivals_2();
		as.clickonbutton();
		as.verifypagecontainsonlythreearrivals();
	}
	
	
	@Test
	public void clickonimageandaddtobasket()
	{
		
		Homepage hm=new Homepage(driver);
		hm.clickonimage();
		hm.addbooktobasket();
		
	}
	

}
