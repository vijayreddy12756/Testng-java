package com.liveproject.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class TC_HomepageArrivalImageReviews_5 extends Baseclass {
	
	@Test
	public void Reviews() throws Exception
	{
		TC_HomepageImageinArrivalNavigate_3 hs=new TC_HomepageImageinArrivalNavigate_3();
		hs.clickandverify();
		hs.clickonimageandaddtobasket();
		//to click on reviewstab
		String Review=driver.findElement(By.xpath("//a[contains(text(),'Reviews (0)')]")).getText();
		System.out.println("reviews are"+ Review);
	}

}
