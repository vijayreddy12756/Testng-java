package com.liveproject.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public  class Homepage {
	
WebDriver ldriver;
	
	public Homepage(WebDriver rdriver)//Constructor
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver,this);
	}
	
	//span[text()='Hello, Sign in']
	
	@FindBy(xpath="//a[contains(text(),'Shop')]")
	WebElement shop;
	
	@FindBy(xpath="//a[contains(text(),'Home')]")
	WebElement home;
	
	@FindBy(xpath="//a[contains(text(),'My Account')]")
	WebElement account;
	
	
	
	@FindBy(xpath="//h3[contains(text(),'Selenium Ruby')]")
	WebElement image;
	
	
	
	@FindBy(xpath="//button[contains(@class,'single_add_to_cart_button button alt')]")
	WebElement addtobasket;
	
	@FindBy(xpath="//a[contains(text(),'Description')]")
	WebElement Description;
	
	@FindBy(xpath="//div[@id='tab-description']//p[contains(text(),'The Selenium WebDriver Recipes book is a quick pro')]")
	WebElement DescriptionParagrapth;

	
	
	public void shopmenu() throws Exception
	{
		
		shop.click();
		Thread.sleep(300);
	}
	
	
	public void homemenu()
	{
		home.click();
		
	}
	
	public void accountmenu()
	{
		account.click();
		
	}
	
	public void clickonimage()
	{
		image.click();
		
	}
	
	public void addbooktobasket()
	{
		addtobasket.click();
		
	}
	
	public void clickondesciptiontab()
	{
		Description.click();
		
		
	}
	
	public String descriptionpara()
	{
		String Pragrapth=DescriptionParagrapth.getText();
		return Pragrapth;
		
		
	}
	
	

}
