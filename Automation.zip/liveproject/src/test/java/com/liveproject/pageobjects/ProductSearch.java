/**
 * 
 */
package com.liveproject.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author girija
 *
 */
public class ProductSearch {
	
	WebDriver ldriver;
	
	public ProductSearch(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver,this);
	}
	
	@FindBy(id="twotabsearchtextbox")
	WebElement Searchtab;
	
	@FindBy(className="nav-input")
	WebElement clickonsearch;  
	
	public void clickonsearchtab()
	{
		Searchtab.sendKeys("Xiaomi Redmi Note 8 64GB + 4GB RAM, 6.3\\\" LTE 48MP Factory Unlocked GSM Smartphone - International Version (Space Black");
	}
	
	public void clickonproductsearch()
	{
		clickonsearch.click();
	}
	
	
	
	
	

}
