/**
 * 
 */
package com.liveproject.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author girija
 * 
 * it contains all locater for login
 *
 */
public class Login {

	WebDriver ldriver;
	
	public Login(WebDriver rdriver)//Constructor
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver,this);
	}
	
	//span[text()='Hello, Sign in']
	
	@FindBy(xpath="//span[text()='Hello, Sign in']")
	WebElement clickonsignin;
	
	@FindBy(xpath="//input[@id='ap_email']")
	WebElement username;
	
	@FindBy(xpath="//input[@id='continue']")
	WebElement contiunebtn;
	
	@FindBy(xpath="//input[@id='ap_password']")
	WebElement password;
	
	@FindBy(xpath="//input[@id='signInSubmit']")
	WebElement loginbtn;
	
	
	public void setsignin() throws InterruptedException
	{
		
		clickonsignin.click();
		Thread.sleep(300);
	}
	
	
	public void setusername(String uname)
	{
		username.clear();
		username.sendKeys(uname);
	}
	
	public void setcontinuebtn()
	{
		contiunebtn.click();
	}
	
	public void setpassword(String pwd)
	{
		password.clear();
		password.sendKeys(pwd);
	}
	
	public void setloginbtn()
	{
		loginbtn.click();
	}
	
	
}
