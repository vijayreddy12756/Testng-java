/**
 * 
 */
package com.liveproject.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * @author girija
 * 
 * this is the mediator class it will read data from config.properties file 
 * 
 * base class will get values from this class
 *
 */
public class Readconfig {
	
	Properties pro;//class need to import from java.util
	
	public Readconfig()//Constructor
	{
		
		File src=new File("./Configurations/config.properties");
		try {
		FileInputStream fis=new FileInputStream(src);//to open file in read mode use fileinput stream
		pro=new Properties();//initiating properties
		pro.load(fis);//load is method loads complete file
		} 
		catch (IOException e) 
		{
			System.out.println("Exception is"+ e.getMessage());
		}
	}
		
		public String getApplicationURL() //methods to read each line in property file
		{
			
			String url=pro.getProperty("BaseUrl");
			return url;
		
	}
		
		public String getusername() //methods to read username in property file
		{
			
			String Username=pro.getProperty("username");
			return Username;
		
	}
	 
		public String getpassword() //methods to read password in property file
		{
			
			String Password=pro.getProperty("password");
			return Password;
		
	}
		
		public String getchromepath() //methods to read chrome path in property file
		{
			
			String Chromepath=pro.getProperty("chromepath");
			return Chromepath;
		
	}
	
		public String getfirefoxpath() //methods to read chrome path in property file
		{
			
			String Firefox=pro.getProperty("firefoxpath");
			return Firefox;
		
	}
	
		public String getIEpath() //methods to read chrome path in property file
		{
			
			String IEpath=pro.getProperty("IEpath");
			return IEpath;
		
	}
	
	
	
	

}
