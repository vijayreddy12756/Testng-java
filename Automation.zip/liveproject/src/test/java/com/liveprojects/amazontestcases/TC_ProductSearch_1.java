/**
 * 
 */
package com.liveprojects.amazontestcases;

import org.testng.annotations.Test;

import com.liveproject.pageobjects.ProductSearch;

/**
 * @author girija
 *
 */
public class TC_ProductSearch_1 extends Baseclasscrossbrowser{
	
	@Test
	public void Productsearch()
	{
		ProductSearch ps=new ProductSearch(driver);
		ps.clickonsearchtab();
		ps.clickonproductsearch();
		
	}
	
	
	
	
	
	
	
	
	
	

}
