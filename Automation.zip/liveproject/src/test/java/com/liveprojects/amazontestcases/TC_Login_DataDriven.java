/**
 * 
 */
package com.liveprojects.amazontestcases;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.liveproject.pageobjects.Login;
import com.liveproject.utilities.XlUtils;

/**
 * @author girija
 *
 */
public class TC_Login_DataDriven extends Baseclasscrossbrowser {
	
	
	
	private int rownum;

	@Test(dataProvider="Logindata")
	public void loginDDT(String username,String Password) throws Exception
	{
		Login lp=new Login(driver);
		lp.setsignin();
		lp.setusername(username);
		lp.setcontinuebtn();
		lp.setpassword(Password);
		lp.setloginbtn();;
		
	}
	
	public boolean isAlertPresent() 
	{ 
	    try 
	    { 
	       String text= driver.switchTo().alert().getText();
	       if(text.equalsIgnoreCase("There was problem"))
	       {
	    	   driver.switchTo().defaultContent();
	    	   
	       }
	        return true; 
	    }   // try 
	    catch (NoAlertPresentException Ex) 
	    { 
	        return false; 
	    }   // catch 
		
	} 
	
	@DataProvider(name="Logindata")
	String[][] getData() throws Exception
	{
		String path=System.getProperty("user.dir")+"\\src\\test\\java\\com\\liveprojects\\testdata\\Login.xlsx";
		//System.out.println(path);
		int rowcount=XlUtils.getRowCount(path, "sheet1");//reading from xlutils.java
		int colcount=XlUtils.getCellCount(path, "sheet1", 1);
		
		String logindata[][]=new String[rowcount][colcount];//create 2d array with rown col count
		
		for(int i=1;i<=rowcount;i++)//row starts from 1
		{
			for(int j=0;j<colcount;j++)//col starts with zero
			{
				
				logindata[i-1][j]=XlUtils.getCellData(path,"Sheet1", i,j);//1 0
			}
		}
		
		return logindata;
		
		
	}
	
	
	
	
	
	
	
	
	
	

}
