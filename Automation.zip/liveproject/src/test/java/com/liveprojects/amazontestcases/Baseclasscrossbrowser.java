/**
 * 
 */
package com.liveprojects.amazontestcases;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.liveproject.utilities.Readconfig;


/**
 * @author girija
 * 
 * this class contains all prerequisites like url,usn,pwd,driver close etc
 * 
 * we can extend this class and access this methods/variable in any class
 * 
 * logger is to get logs
 * 
 * log4j.properties file need to download and modify format and location of logs
 *
 */
public class Baseclasscrossbrowser {
	
	Readconfig readcofig=new Readconfig();//create object of readconfig file in utility class that provide url,username ,pwd ect
	
	public String BaseUrl=readcofig.getApplicationURL();//calling this methods from readconfig file
	public String username=readcofig.getusername();
	public String password=readcofig.getpassword();
	public static WebDriver driver;
	
	public static Logger logger;
	
	@Parameters({"Browser"})
	@BeforeClass
	public void setup(String br) 
	{
		
		logger=Logger.getLogger("liveproject");
		PropertyConfigurator.configure("log4j.properties");
		
		if(br.equalsIgnoreCase("chrome"))
		{
	System.setProperty("webdriver.chrome.driver",readcofig.getchromepath());
	driver =new ChromeDriver();
	driver.manage().window().maximize();
	
	
		}
		
		else if(br.equalsIgnoreCase("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver",readcofig.getfirefoxpath());
			driver = new FirefoxDriver();
		}
		
		else if(br.equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver",readcofig.getIEpath());
			driver = new InternetExplorerDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get(BaseUrl);
		driver.manage().window().maximize();
		
	}
	
    @AfterClass
	public void teardown()
	{
		driver.quit();
	}
    
    public void captureScreen(WebDriver driver, String tname) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File target = new File(System.getProperty("user.dir") + "/Screenshots/" + tname + ".png");
		FileHandler.copy(source, target);
		System.out.println("Screenshot taken");
	}
	
		
	
	
	

}
