/**
 * 
 */
package com.liveprojects.amazontestcases;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.liveproject.pageobjects.Login;

/**
 * @author girija
 * 
 * need to import login page from com.liveproject.pageobjects to access page object methods
 * 
 * need to extend base class to access reusable methods
 *
 */
public class TC_Login_1 extends Baseclasscrossbrowser{
	
	@Test
	public void loginTest() throws InterruptedException, Exception
	{
	
	Login lp=new Login(driver);	
	lp.setsignin();
	lp.setusername(username);//username from base class
	lp.setcontinuebtn();
	lp.setpassword(password);//password from base class
	lp.setloginbtn();
	logger.info("loginTestcase");
	//String actual_title="amazon";
	String expected_title=driver.getTitle();
	
	//System.out.printf("expected title is",expected_title);
	
	captureScreen(driver,"login");//when test case failed it will call capturescreen method in base class
	Assert.assertTrue(expected_title.contains("amazon.com"));
	
	
	
	
		
		
		
		
		
		
		
		
		
		
		
	}

}
